#include <R_ext/RS.h>
#include <stdlib.h> // for NULL
#include <R_ext/Rdynload.h>

/* FIXME: 
   Check these declarations against the C/Fortran source code.
*/

/* .Fortran calls */
extern void F77_NAME(bdiag)(void *, void *, void *);
extern void F77_NAME(ecme3)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(mgibbs)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(mgibbsbd)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(nopsi)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(prelim)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(rngs)(void *);

static const R_FortranMethodDef FortranEntries[] = {
    {"bdiag",    (DL_FUNC) &F77_NAME(bdiag),     3},
    {"ecme3",    (DL_FUNC) &F77_NAME(ecme3),    43},
    {"mgibbs",   (DL_FUNC) &F77_NAME(mgibbs),   44},
    {"mgibbsbd", (DL_FUNC) &F77_NAME(mgibbsbd), 46},
    {"nopsi",    (DL_FUNC) &F77_NAME(nopsi),    34},
    {"prelim",   (DL_FUNC) &F77_NAME(prelim),   17},
    {"rngs",     (DL_FUNC) &F77_NAME(rngs),      1},
    {NULL, NULL, 0}
};

void R_init_pan(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, NULL, FortranEntries, NULL);
    R_useDynamicSymbols(dll, FALSE);
}
