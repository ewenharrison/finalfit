### R code from vignette source 'zoo-design.Rnw'

###################################################
### code chunk number 1: preliminaries
###################################################
library("zoo")
Sys.setenv(TZ = "GMT")


