write_lines("I should be automatically deleted", "DELETE-ME")
