for (i in 1:2) {
  plot(i)
  cat(i)
}
