
if(require(testthat) && require(ordinal)) {
    test_check("ordinal")
}
