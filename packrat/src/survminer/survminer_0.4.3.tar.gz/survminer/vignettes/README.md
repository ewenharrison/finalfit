`ggsci.css` was borrowed from [`ggsci`](https://github.com/road2stat/ggsci/tree/master/vignettes) package
