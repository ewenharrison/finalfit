

#' @export
# @examples
# ggsave("test.pdf", ggpairs(iris, 1:2))
grid.draw.ggmatrix <- function(x, ...) {
  print(x)
}
