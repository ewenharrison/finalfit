#' The htmldeps package provides centralized functions for
#' HTML dependencies for several packages
#' @keywords internal
"_PACKAGE"
