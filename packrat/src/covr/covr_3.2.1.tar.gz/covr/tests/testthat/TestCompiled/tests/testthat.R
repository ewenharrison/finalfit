library(testthat)
library("TestCompiled")

test_check("TestCompiled")
