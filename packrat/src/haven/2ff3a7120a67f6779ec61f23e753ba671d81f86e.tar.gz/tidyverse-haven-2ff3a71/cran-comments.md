This is a resubmission that fixes the rchk problem. Contrary to my previous email, I believe that the gcc8 issue has already been fixed upstream.

---

## Test environments
* local OS X install: R-release
* travis-ci: R-3.1, R-3.2, R-oldrel, R-release, R-devel
* win-builder: R-devel

## R CMD check results
0 ERRORs | 0 WARNINGs | 1 NOTEs

* checking for GNU extensions in Makefiles ... NOTE
  GNU make is a SystemRequirements.

## revdepcheck results

We checked 42 reverse dependencies (38 from CRAN + 4 from BioConductor), comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 0 new problems
 * We failed to check 0 packages
