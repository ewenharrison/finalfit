## another name for update()
transform.survey.design<-function(`_data`, ...) update(`_data`,...)
transform.svyrep.design<-function(`_data`, ...) update(`_data`,...)
transform.twophase<-function(`_data`, ...) update(`_data`,...)
transform.twophase2<-function(`_data`, ...) update(`_data`,...)
transform.ODBCsvydesign<-function(`_data`, ...) update(`_data`,...)
transform.DBIsvydesign<-function(`_data`, ...) update(`_data`,...)
transform.svyimputationList<-function(`_data`, ...) update(`_data`,...)

