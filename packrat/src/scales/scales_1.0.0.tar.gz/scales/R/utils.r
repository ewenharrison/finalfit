# Evaluates all arguments (see #81)
force_all <- function(...) list(...)
